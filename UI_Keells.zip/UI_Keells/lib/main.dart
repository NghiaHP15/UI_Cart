import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

////////////////////////////////////////////////////////////////////////////////
class Menu {
  int id;
  String title;
  Image image;
  Menu({required this.id, required this.title, required this.image});
}

////////////////////////////////////////////////////////////////////////////////
class Nexus {
  int id;
  String title;
  int mass;
  double price;
  Image image;
  bool favarite;
  Nexus(
      {required this.id,
      required this.title,
      required this.price,
      required this.mass,
      required this.image,
      required this.favarite});
}

////////////////////////////////////////////////////////////////////////////////
class Keell {
  int id;
  String title;
  int mass;
  double price;
  Image image;
  bool favarite;
  Keell(
      {required this.id,
      required this.title,
      required this.price,
      required this.mass,
      required this.image,
      required this.favarite});
}

////////////////////////////////////////////////////////////////////////////////
List<Menu> FAKE_CATEGORIES = [
  Menu(
    id: 0,
    title: 'Household',
    image: Image.asset('assets/image/fashion.png'),
  ),
  Menu(
    id: 1,
    title: 'Grocery',
    image: Image.asset('assets/image/beauty.png'),
  ),
  Menu(
    id: 2,
    title: 'Liquor',
    image: Image.asset('assets/image/electronics.png'),
  ),
  Menu(
    id: 3,
    title: 'Chilled',
    image: Image.asset('assets/image/jewellery.png'),
  ),
  Menu(
    id: 4,
    title: 'Cheesse',
    image: Image.asset('assets/image/footwear.png'),
  ),
  Menu(
    id: 5,
    title: 'Potato',
    image: Image.asset('assets/image/toys.png'),
  ),
];

////////////////////////////////////////////////////////////////////////////////
List<Nexus> FAKE_NEXUS = [
  Nexus(
    id: 0,
    title: 'Ginner',
    mass: 1,
    price: 690.00,
    favarite: true,
    image: Image.asset('assets/image/ginner.png'),
  ),
  Nexus(
    id: 1,
    title: 'Gralic Premium',
    mass: 1,
    price: 380.00,
    favarite: false,
    image: Image.asset('assets/image/GralicPremium.png'),
  ),
  Nexus(
    id: 2,
    title: 'Red Onions',
    mass: 1,
    price: 260.00,
    favarite: false,
    image: Image.asset('assets/image/RedOnions.png'),
  ),
  Nexus(
    id: 3,
    title: 'Potato',
    mass: 1,
    price: 390.00,
    favarite: true,
    image: Image.asset('assets/image/Potato.png'),
  ),
  Nexus(
    id: 4,
    title: 'Temongrass',
    mass: 1,
    price: 540.00,
    favarite: false,
    image: Image.asset('assets/image/TemongrassTubers.png'),
  ),
];

////////////////////////////////////////////////////////////////////////////////
List<Keell> FAKE_KEELL = [
  Keell(
    id: 0,
    title: 'Carrot',
    mass: 1,
    price: 490.00,
    favarite: false,
    image: Image.asset('assets/image/Carrot.png'),
  ),
  Keell(
    id: 1,
    title: 'Mango - Blue',
    mass: 1,
    price: 210.00,
    favarite: true,
    image: Image.asset('assets/image/MangoBlue.png'),
  ),
  Keell(
    id: 2,
    title: 'Grapes - Green',
    mass: 1,
    price: 990.00,
    favarite: false,
    image: Image.asset('assets/image/Grapes.png'),
  ),
  Keell(
    id: 3,
    title: 'Apple - green',
    mass: 1,
    price: 390.00,
    favarite: true,
    image: Image.asset('assets/image/Apple.png'),
  ),
  Keell(
    id: 4,
    title: 'Banana',
    mass: 1,
    price: 540.00,
    favarite: false,
    image: Image.asset('assets/image/Banana.png'),
  ),
];

////////////////////////////////////////////////////////////////////////////////
class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 76, 175, 92),
          leading: IconButton(
            icon: const Icon(
              Icons.filter_alt_outlined,
              size: 27,
            ),
            onPressed: () {},
          ),
          title: const Text('Keells'),
          centerTitle: true,
          actions: [
            IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.search,
                size: 27,
              ),
            ),
            Stack(
              children: [
                IconButton(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  onPressed: () {},
                  icon: const Icon(
                    Icons.notifications_none_outlined,
                    size: 27,
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: Container(
                    height: 10,
                    width: 10,
                    decoration: ShapeDecoration(
                        color: Color.fromARGB(255, 248, 252, 255),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5))),
                  ),
                ),
              ],
            ),
          ],
        ),
        backgroundColor: Color.fromARGB(255, 248, 254, 255),
        body: SafeArea(
          child: ListView(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Title(
                          color: Colors.black,
                          child: const Text(
                            'All Categories',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              height: -0.0000001,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () {},
                          child: Row(
                            children: const [
                              Text(
                                'View all',
                                style: TextStyle(
                                    height: 1,
                                    color: Colors.green,
                                    fontSize: 14),
                              ),
                              Icon(
                                Icons.navigate_next,
                                color: Colors.green,
                                size: 16,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                    Container(
                      height: 120,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: FAKE_CATEGORIES.length,
                        itemBuilder: (context, index) {
                          final item = FAKE_CATEGORIES[index];
                          return Container(
                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.only(
                                      bottom: 10, left: 3, right: 3, top: 10),
                                  height: 94,
                                  child: item.image,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      item.title,
                                      style: const TextStyle(
                                          color:
                                              Color.fromARGB(255, 27, 27, 27),
                                          fontSize: 14),
                                    ),
                                    const Icon(
                                      Icons.navigate_next,
                                      color: Color.fromARGB(255, 27, 27, 27),
                                      size: 16,
                                    )
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Title(
                          color: Colors.black,
                          child: const Text(
                            'Nexus Menber Deal',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              height: -0.0000001,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () {},
                          child: Row(
                            children: const [
                              Text(
                                'View all',
                                style: TextStyle(
                                    height: 1,
                                    color: Colors.green,
                                    fontSize: 14),
                              ),
                              Icon(
                                Icons.navigate_next,
                                color: Colors.green,
                                size: 16,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                    Container(
                      height: 180,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: FAKE_NEXUS.length,
                        itemBuilder: (context, index) {
                          final item = FAKE_NEXUS[index];
                          return Container(
                            child: Column(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.only(
                                          bottom: 10,
                                          left: 4,
                                          right: 4,
                                          top: 10),
                                      width: 120,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(2),
                                        boxShadow: [
                                          BoxShadow(
                                            offset: Offset(0, 0),
                                            spreadRadius: 1,
                                            blurRadius: 2,
                                            color:
                                                Color.fromARGB(255, 58, 58, 58)
                                                    .withOpacity(0.1),
                                          ),
                                        ],
                                      ),
                                      child: item.image,
                                    ),
                                    Positioned(
                                      top: 15,
                                      left: 10,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 3),
                                        decoration: BoxDecoration(
                                            color: Colors.grey,
                                            borderRadius:
                                                BorderRadius.circular(2)),
                                        child: Text(
                                          '${item.mass}KG',
                                          style: const TextStyle(
                                            fontSize: 10,
                                            color: Colors.white,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 5,
                                      right: 0,
                                      child: IconButton(
                                        color: item.favarite
                                            ? Colors.green
                                            : Colors.grey,
                                        icon: item.favarite
                                            ? Icon(Icons.favorite)
                                            : Icon(Icons.favorite_outline),
                                        onPressed: () {
                                          setState(() {
                                            item.favarite
                                                ? item.favarite = false
                                                : item.favarite = true;
                                          });
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  width: 100,
                                  alignment: Alignment.centerLeft,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            item.title,
                                            style: const TextStyle(
                                                color: Color.fromARGB(
                                                    255, 27, 27, 27),
                                                fontSize: 14),
                                          ),
                                        ],
                                      ),
                                      Text(
                                        'Rs.${item.id}',
                                        style: const TextStyle(
                                            color:
                                                Color.fromARGB(255, 27, 27, 27),
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Title(
                          color: Colors.black,
                          child: const Text(
                            'Keells Deals',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              height: -0.0000001,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () {},
                          child: Row(
                            children: const [
                              Text(
                                'View all',
                                style: TextStyle(
                                    height: 1,
                                    color: Colors.green,
                                    fontSize: 14),
                              ),
                              Icon(
                                Icons.navigate_next,
                                color: Colors.green,
                                size: 16,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                    Container(
                      alignment: Alignment.centerLeft,
                      height: 180,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: FAKE_KEELL.length,
                        itemBuilder: (context, index) {
                          final item = FAKE_KEELL[index];
                          return Column(
                            children: [
                              Stack(
                                children: [
                                  Container(
                                    margin: const EdgeInsets.only(
                                        bottom: 10, left: 4, right: 4, top: 10),
                                    width: 120,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(2),
                                      boxShadow: [
                                        BoxShadow(
                                          offset: Offset(0, 0),
                                          spreadRadius: 1,
                                          blurRadius: 2,
                                          color: Color.fromARGB(255, 58, 58, 58)
                                              .withOpacity(0.1),
                                        ),
                                      ],
                                    ),
                                    child: item.image,
                                  ),
                                  Positioned(
                                    top: 15,
                                    left: 10,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 3),
                                      decoration: BoxDecoration(
                                          color: Colors.grey,
                                          borderRadius:
                                              BorderRadius.circular(2)),
                                      child: Text(
                                        '${item.mass}KG',
                                        style: const TextStyle(
                                          fontSize: 10,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 5,
                                    right: 0,
                                    child: IconButton(
                                      color: item.favarite
                                          ? Colors.green
                                          : Colors.grey,
                                      icon: item.favarite
                                          ? Icon(Icons.favorite)
                                          : Icon(Icons.favorite_outline),
                                      onPressed: () {
                                        setState(() {
                                          item.favarite
                                              ? item.favarite = false
                                              : item.favarite = true;
                                        });
                                      },
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                alignment: Alignment.centerLeft,
                                width: 100,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.title,
                                      style: const TextStyle(
                                          color:
                                              Color.fromARGB(255, 27, 27, 27),
                                          fontSize: 14),
                                    ),
                                    Text(
                                      'Rs.${item.price}.00',
                                      style: const TextStyle(
                                          color:
                                              Color.fromARGB(255, 27, 27, 27),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: BottomAppBar(
          elevation: 0.1,
          child: Container(
            padding: EdgeInsets.only(bottom: 5, left: 20, right: 20),
            height: 65,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                BottomApp('Store', Icon(Icons.storefront_outlined)),
                BottomApp('My Cart', Icon(Icons.shopping_bag_outlined)),
                BottomApp('Favuorites', Icon(Icons.favorite_outline)),
                BottomApp('Profile', Icon(Icons.person_outline)),
                BottomApp('More', Icon(Icons.more_horiz_outlined)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Column BottomApp(String content, Icon icon) {
    return Column(
      children: [
        IconButton(
          padding: EdgeInsets.only(top: 10),
          icon: Icon(
            icon.icon,
            size: 30,
            color: Colors.grey,
          ),
          onPressed: () {},
        ),
        Title(
          color: Colors.grey,
          child: Text(
            content,
            style: TextStyle(fontSize: 12, height: -0, color: Colors.grey),
          ),
        ),
      ],
    );
  }
}
